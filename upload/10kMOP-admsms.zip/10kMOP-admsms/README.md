# 10kMOP

项目目标:提供客户查看/上传数据/生成图表/查看项目进度等 <br/>

### python依赖：
appdirs==1.4.0 <br/>
Django==1.10.5 <br/>
django-filter==1.0.1 <br/>
django-model-utils==2.6.1 <br/>
django-notifications-hq==1.2 <br/>
djangorestframework==3.5.4 <br/>
et-xmlfile==1.0.1 <br/>
gunicorn==19.6.0 <br/>
jdcal==1.3 <br/>
jsonfield==1.0.3 <br/>
Markdown==2.6.8 <br/>
mysqlclient==1.3.10 <br/>
numpy==1.12.0 <br/>
olefile==0.44 <br/>
openpyxl==2.4.2 <br/>
packaging==16.8 <br/>
pandas==0.19.2 <br/>
Pillow==4.0.0 <br/>
pyparsing==2.1.10 <br/>
python-dateutil==2.6.0 <br/>
pytz==2016.10 <br/>
requests==2.13.0 <br/>
six==1.10.0 <br/>
xlrd==1.0.0 <br/>



## 数据模型
用户：user (extend profile)<br>
项目：Project <br>
项目文件数据：Data<br>
用户上传的文件数据：SelfData<br>



## 基本功能模块：<br>
1.用户模块/包括修改密码/修改用户基本信息等<br>
2.分析画图功能,读入excel表,提供用户自行作图,可选择服务器上的文件数据,也可上传用户本地数据<br>
3.项目进度展示/查看黑白名单数据<br>
4.数据展示/分为项目数据以及用户数据<br>
   其中项目数据与用户数据君提供下载以及分析画图,项目数据还可提供用户上传数据合并，生成合并文件，提提供用户选择下载和画图功能。<br>
5.管理后台/对数据模型进行管理<br>
6.api接口/传送及接收文件数据<br>


### 分析画图模块简单说明

散点图<br>

1.只选择x轴时,y轴为index order.只选择y轴时,x轴为index order.此时可以依据相应x/y轴排序<br>

2.作图时可定义X/Y轴类型,目前支持value(数字),category(字符)<br>

箱线图<br>

1.x/y轴必须选择,其中一个为(values)连续变量，另一个则不能为连续变量(category)<br>

2.注意时间值格式为:20170101时若作为数字类型读入,作图时注意修改为,category(字符)<br>

统计(柱状图,折线图，饼图)<br>

1.只选择x轴或y轴时,统计出该字段的总数比例(生成两张图)<br>

2.选择X/Y时,当X/Y不是一一对应时,自动转为散点图<br>


### api接口说明

数据API接口： url/datas_api/
<br>
项目API接口： url/datas_api/
<br>
认证方法： post 数据时 带上管理员账号密码/

python例子：<br>

<pre><code>
class MopApi(object):
    def __init__(self, account, password):
        self.account = account
        self.password = password

    def get_users(self):
        users_url = url + 'users_api/'
        users = requests.get(users_url, auth=(self.account, self.password), headers=headers)
        return users.text

    def get_datas(self):
        datas_url = url + 'datas_api/'
        datas = requests.get(datas_url, auth=(self.account, self.password), headers=headers)
        return datas.text

    def get_projects(self):
        projects_url = url + 'projects_api/'
        projects = requests.get(projects_url, auth=(self.account, self.password), headers=headers)
        return projects.text

    def post_datas(self, filename=None, project=None):
        datas_url = url + 'datas_api/'
        if filename is None:
            return 'filename can not be None!please input a upload filename!'
        else:
            files = {'file': open(filename, 'rb')}
        if project is not None:
            postData = {
                "project": project,
            }
            tt = requests.post(datas_url, auth=(self.account, self.password), files=files, data=postData)
            print(tt)
        else:
            tt = requests.post(datas_url, auth=(self.account, self.password), files=files)
        print(tt)
        return tt.text


    def post_projects(self, name, progress,black_file, white_file):
        project_url = url + 'projects_api/'
        if black_file is not None and white_file is not None:
            files = {'white_file': open(white_file, 'rb'), 'black_file': open(black_file, 'rb')}
            if name is not None:
                postData = {
                    "name": name,
                    "progress": progress,
                    "post_flag": True,
                }
                tt = requests.post(project_url, auth=(self.account, self.password), files=files, data=postData)
            else:
                tt = requests.post(project_url, auth=(self.account, self.password), files=files)
        else:
            return 'filename can not be None!please input a upload filename!'
        return tt.text
</code></pre>


具体实现脚本：<br>

使用API方法封装：<br>
https://github.com/weihongx/alan/blob/master/10k_api_script/tenkmop_api_using.py

发送黑白名单文件：<br>
https://github.com/weihongx/alan/blob/master/10k_api_script/white_black_collections.py

发送数据文件：<br>
https://github.com/weihongx/alan/blob/master/10k_api_script/qa_run_info_collections.py


