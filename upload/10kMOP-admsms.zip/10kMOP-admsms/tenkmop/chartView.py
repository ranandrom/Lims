from django.shortcuts import render, HttpResponse
from tenkmop.models import *
from django.views.decorators.csrf import csrf_exempt
import urllib
import os
import json
from tenkmop.utils.chartutils import ChartLoadFile,Echart,MyEncoder, format_excel
import urllib.parse
import datetime
from django.contrib.auth.decorators import login_required
from tenkmop.models import Project
from django.conf import settings


# 主页
@login_required()
def anchor_chart(req):
    return render(req, 'anchordxChart.html', locals())


# 取得树形目录页面
@login_required()
def chart_tree(req):
    self_upload = os.path.join(os.path.join(settings.MEDIA_DIR, 'self_upload'), req.user.username)
    if not os.path.isdir(self_upload):
        os.makedirs(self_upload)

    upload = os.path.join(settings.MEDIA_DIR, 'upload')
    return render(req, 'anchorchartree.html', locals())


# 树形显示文件,提供选择
@csrf_exempt
@login_required()
def dir_list_for_chart(request):
    r = ['<ul class="jqueryFileTree" style="display: none;">']
    projects = [p.name for p in Project.objects.prefetch_related('user').filter(user=request.user).all()]  # 取得用户所属项目
    try:
        r = ['<ul class="jqueryFileTree" style="display: none;">']
        d = urllib.parse.unquote(request.POST.get('dir', '/home'))
        for f in sorted(os.listdir(d)):
            ff=os.path.join(d,f)
            if any(p in ff for p in projects):  # 只能看到所属项目文件夹
                if os.path.isdir(ff):
                    r.append('<li class="directory collapsed"><a href="#" rel="%s/">%s</a></li>' % (ff, f))
                else:
                    e=os.path.splitext(f)[1][1:] # get .ext and remove dot
                    if e == "xlsx" or e == "xls" or e =="csv":
                        r.append('<li class="file ext_%s"><a href="#" rel="%s">%s</a></li>' % (e, ff, f))
                    else:
                        r.append('<li class="file ext_%s"></li>' % (e))
        r.append('</ul>')
    except Exception as e:
        r.append('Could not load directory: {}'.format(str(e)))
    r.append('</ul>')
    return HttpResponse(''.join(r))


# 树形显示文件,用户自行上传的文件
@csrf_exempt
@login_required()
def dir_list_for_chart_self(request):
    r = ['<ul class="jqueryFileTree" style="display: none;">']
    try:
        r = ['<ul class="jqueryFileTree" style="display: none;">']
        d = urllib.parse.unquote(request.POST.get('dir', '/home'))
        for f in sorted(os.listdir(d)):
            ff=os.path.join(d,f)
            if os.path.isdir(ff):
                r.append('<li class="directory collapsed"><a href="#" rel="%s/">%s</a></li>' % (ff, f))
            else:
                e=os.path.splitext(f)[1][1:] # get .ext and remove dot
                if e == "xlsx" or e == "xls" or e =="csv":
                    r.append('<li class="file ext_%s"><a href="#" rel="%s">%s</a></li>' % (e, ff, f))
                else:
                    r.append('<li class="file ext_%s"></li>' % (e))
        r.append('</ul>')
    except Exception as e:
        r.append('Could not load directory: {}'.format(str(e)))
    r.append('</ul>')
    return HttpResponse(''.join(r))


# 获得各字段
@csrf_exempt
@login_required()
def get_col_names(req):
    if req.method == 'POST':
        filename = req.POST.get('filename') or req.FILES.get('inputFile') or req.POST.get('inputFile') or req.POST.get('fileload')
        excelsheet = int(req.POST.get('excelsheet', -1))
        e = os.path.splitext(str(filename))[1][1:]  # get .ext and remove dot
        if e != 'xlsx' or e != "xls" or e != 'csv' or e != 'json':
            HttpResponse(json.dumps({'errors': "file not found,please check or contract administrator"}),
                         content_type="application/json")

        if req.FILES.get('inputFile'):
            strtime = datetime.datetime.now().strftime('%Y-%m-%d')
            uploaddir = 'media/self_upload/%s/%s/' % (req.user.username, strtime)
            if not os.path.exists(uploaddir):
                os.makedirs(uploaddir)
            with open('%s%s' % (uploaddir,filename), 'wb+') as destination:
                for chunk in filename.chunks():
                    destination.write(chunk)

            filename = '%s%s' % (uploaddir,filename)

            if e == "xlsx" or e == "xls":
                format_excel(filename)

            file_path = 'self_upload/{}/{}/{}'.format(req.user.username, strtime, req.FILES.get('inputFile'))
            self_data = SelfData.objects.filter(name=req.FILES.get('inputFile')).first()
            if not self_data:
                SelfData(name=req.FILES.get('inputFile'),  file_type=e, user=req.user,
                         size=str(
                             round(os.stat(os.path.join(settings.MEDIA_DIR, file_path)).st_size / 1024 / 1024, 3)) + 'M',
                         file=file_path).save()
            else:
                self_data.size = str(round(os.stat(os.path.join(settings.MEDIA_DIR, file_path)).st_size / 1024 / 1024, 3)) + 'M'
                self_data.save()

        try:
            tumorload = ChartLoadFile(filename,excelsheet)
            colnames,dataframe = tumorload.get_columnnames()
            sheetnames = tumorload.get_sheet_names(filename)
            typenames = tumorload.get_type_names()
        except :
            colnames, typenames, sheetnames, dataframe= [], [], [], []
            HttpResponse(json.dumps({'errors': "file not accept,please check or contract administrator"}), content_type="application/json")

        return HttpResponse(json.dumps({'colnames': colnames,'typenames': typenames,'filename':filename,
                                        'sheetnames':sheetnames,
                                        'dataframe':list(set(dataframe)),
                                        "success":True}), content_type="application/json")

# 散点图
def chart_scatter(chartload,colnames,tumorload_chart,xcol=-1, ycol=-1, sorttype=None, typecol=-1,charttype=None,xtype=None,ytype=None,msg=None):
    if ycol >= 0 and xcol < 0 and typecol < 0:
        datas = [
            chartload.get_column_data(ycol=ycol, sorttype=sorttype, charttype=charttype, ytype=ytype)]
        ycolnames = colnames[ycol].replace('\n','')
        title = tumorload_chart.get_title(text="Anchordx {} chart for {}".format(charttype, ycolnames))
        tooltip = tumorload_chart.get_tooltip(trigger='item')
        legend = tumorload_chart.get_legend(ycolnames)
        xAxis = tumorload_chart.get_axis(name="Order/Count", position='bottom', nameLocation='middle', nameGap=25)
        ydata = chartload.get_only_column_data(ycol)
        nameNum = [ycolnames]

        if all([isinstance(x, (str)) for x in ydata]):
            yAxis = tumorload_chart.get_axis(name=ycolnames, type='category', position="top",
                                             data=sorted(list(set(ydata))), reversed=True)
        elif all([isinstance(x, (float, int)) for x in ydata]):
            yAxis = tumorload_chart.get_axis(type='value', name=ycolnames)
        else:
            yAxis = tumorload_chart.get_axis(name=ycolnames)

    # only x
    elif ycol < 0 and xcol >= 0 and typecol < 0:
        datas = [chartload.get_column_data(xcol=xcol, sorttype=sorttype, charttype=charttype, xtype=xtype)]

        xcolnames = colnames[xcol].replace('\n','')
        title = tumorload_chart.get_title(text="Anchordx {} chart for {}".format(charttype, xcolnames))
        tooltip = tumorload_chart.get_tooltip(trigger='item')
        legend = tumorload_chart.get_legend(xcolnames)
        xdata = chartload.get_only_column_data(xcol)
        nameNum = [xcolnames]

        if all([isinstance(x, (str)) for x in xdata]):
            xAxis = tumorload_chart.get_axis(name=xcolnames, type='category', data=sorted(list(set(xdata))),
                                             position='bottom', nameLocation='middle', nameGap=25)
        elif all([isinstance(x, (float, int)) for x in xdata]):
            xAxis = tumorload_chart.get_axis(type='value', name=xcolnames, position='bottom', nameLocation='middle',
                                             nameGap=25)
        else:
            xAxis = tumorload_chart.get_axis(name=xcolnames)

        yAxis = tumorload_chart.get_axis(name="Order/Count")

    # x and y
    elif xcol >= 0 and ycol >= 0 and typecol < 0:
        datas,corr,cov = chartload.get_column_data(xcol=xcol, ycol=ycol, sorttype=sorttype, charttype=charttype, xtype=xtype,
                                                   ytype=ytype)
        datas = [datas]
        xcolnames = colnames[xcol].replace('\n','')
        ycolnames = colnames[ycol].replace('\n','')
        title1 = tumorload_chart.get_title(
            text="TumorLoad {} chart for {} and {}".format(charttype, xcolnames, ycolnames),

        )
        if corr and cov:
            title2 = tumorload_chart.get_title(
                text="相关系数: {}".format(corr),
                right='40%',
                top='3%',
            )
            title3 = tumorload_chart.get_title(
                text="协方差: {}".format(cov),
                right='20%',
                top='3%',
            )
            title = [title1, title2, title3]
        else:
            title = title1
        tooltip = tumorload_chart.get_tooltip(trigger='item')
        legend = tumorload_chart.get_legend(ycolnames)
        xdata = chartload.get_only_column_data(xcol)
        ydata = chartload.get_only_column_data(ycol)
        nameNum = [ycolnames]
        if all([isinstance(x, (str)) for x in xdata]):
            xAxis = tumorload_chart.get_axis(name=xcolnames, type='category', data=sorted(list(set(xdata))),
                                             position='bottom', nameLocation='middle', nameGap=25)
        elif all([isinstance(x, (float, int)) for x in xdata]):
            xAxis = tumorload_chart.get_axis(type='value', name=xcolnames, position='bottom', nameLocation='middle',
                                             nameGap=25)
        else:
            xAxis = tumorload_chart.get_axis(name=xcolnames)

        if all([isinstance(x, (str)) for x in ydata]):
            yAxis = tumorload_chart.get_axis(name=ycolnames, type='category', position="top",
                                             data=sorted(list(set(ydata))))
        elif all([isinstance(x, (float, int)) for x in ydata]):
            yAxis = tumorload_chart.get_axis(type='value', name=ycolnames)
        else:
            yAxis = tumorload_chart.get_axis(name=ycolnames)


    # x,type
    elif ycol < 0 and xcol >= 0 and typecol >= 0:
        typenames = chartload.get_typenames(typecol=typecol)
        datas = chartload.get_column_data(xcol=xcol, typecol=typecol, sorttype=sorttype, charttype=charttype,
                                          xtype=xtype)
        xcolnames = colnames[xcol].replace('\n','')
        ycolnames = 'Count'
        typecolnames = colnames[typecol]
        title = tumorload_chart.get_title(
            text="Anchordx {} chart for {} with type:{}".format(charttype, xcolnames, typecolnames))
        tooltip = tumorload_chart.get_tooltip(trigger='item')
        legend = tumorload_chart.get_legend(position=['right', 'center'], data=sorted(typenames), orient='vertical')
        xdata = chartload.get_only_column_data(xcol)
        nameNum = sorted(typenames)
        if all([isinstance(x, (str)) for x in xdata]):
            xAxis = tumorload_chart.get_axis(name=xcolnames, type='category', data=sorted(list(set(xdata))),
                                             position='bottom', nameLocation='middle', nameGap=25)
        elif all([isinstance(x, (float, int)) for x in xdata]):
            xAxis = tumorload_chart.get_axis(type='value', name=xcolnames, position='bottom',
                                             nameLocation='middle', nameGap=25)
        else:
            xAxis = tumorload_chart.get_axis(name=xcolnames)

        yAxis = tumorload_chart.get_axis(name=ycolnames)

    # y,type
    elif ycol >= 0 and xcol < 0 and typecol >= 0:
        typenames = chartload.get_typenames(typecol=typecol)
        datas = chartload.get_column_data(ycol=ycol, typecol=typecol, sorttype=sorttype, charttype=charttype,
                                          ytype=ytype)

        ycolnames = colnames[ycol].replace('\n','')
        xcolnames = "Count"
        typecolnames = colnames[typecol]
        title = tumorload_chart.get_title(
            text="Anchordx {} chart for {} with type:{}".format(charttype, ycolnames, typecolnames))
        tooltip = tumorload_chart.get_tooltip(trigger='item')
        legend = tumorload_chart.get_legend(position=['right', 'center'], data=sorted(typenames), orient='vertical')
        ydata = chartload.get_only_column_data(ycol)
        nameNum = sorted(typenames)

        if all([isinstance(x, (str)) for x in ydata]):
            yAxis = tumorload_chart.get_axis(name=ycolnames, type='category', position="top",
                                             data=sorted(list(set(ydata))))
        elif all([isinstance(x, (float, int)) for x in ydata]):
            yAxis = tumorload_chart.get_axis(type='value', name=ycolnames)
        else:
            yAxis = tumorload_chart.get_axis(name=ycolnames)

        xAxis = tumorload_chart.get_axis(name=xcolnames, position='bottom', nameLocation='middle', nameGap=25)

    # x , y , type
    elif xcol >= 0 and typecol >= 0 and ycol >= 0:
        typenames = chartload.get_typenames(typecol=typecol)
        datas,corr,cov = chartload.get_column_data(typecol=typecol, xcol=xcol, ycol=ycol, sorttype=sorttype,
                                                   charttype=charttype, xtype=xtype, ytype=ytype)

        xcolnames = colnames[xcol].replace('\n','')
        ycolnames = colnames[ycol].replace('\n','')
        typecolnames = colnames[typecol]
        title1 = tumorload_chart.get_title(
            text="TumorLoad {} chart for {} and {} with type:{}".format(charttype, xcolnames, ycolnames,
                                                                        typecolnames))
        if corr and cov:
            title2 = tumorload_chart.get_title(
                text="相关系数: {}".format(corr),
                right='40%',
                top='3%',
            )
            title3 = tumorload_chart.get_title(
                text="协方差: {}".format(cov),
                right='20%',
                top='3%',
            )
            title = [title1, title2, title3]
        else:
            title = title1
        tooltip = tumorload_chart.get_tooltip(trigger='item')
        xdata = chartload.get_only_column_data(xcol)
        ydata = chartload.get_only_column_data(ycol)
        legend = tumorload_chart.get_legend(position=['right', 'center'], data=sorted(typenames), orient='vertical')
        nameNum = sorted(typenames)
        if all([isinstance(x, (str)) for x in xdata]):
            xAxis = tumorload_chart.get_axis(name=xcolnames, type='category', data=sorted(list(set(xdata))),
                                             position='bottom', nameLocation='middle', nameGap=25)
        elif all([isinstance(x, (float, int)) for x in xdata]):
            xAxis = tumorload_chart.get_axis(type='value', name=xcolnames, position='bottom',
                                             nameLocation='middle', nameGap=25)
        else:
            xAxis = tumorload_chart.get_axis(name=xcolnames)

        if all([isinstance(x, (str)) for x in ydata]):
            yAxis = tumorload_chart.get_axis(name=ycolnames, type='category', position="top",
                                             data=sorted(list(set(ydata))))
        elif all([isinstance(x, (float, int)) for x in ydata]):
            yAxis = tumorload_chart.get_axis(type='value', name=ycolnames)
        else:
            yAxis = tumorload_chart.get_axis(name=ycolnames)
    else:
        title, tooltip, legend, xAxis, yAxis, totaldatas, nameNum, datas = '', '', '', '', '', '', '', '',


    return HttpResponse(json.dumps(
        {'title': title, 'tooltip': tooltip, 'legend': legend, 'xAxis': xAxis, 'yAxis': yAxis, 'nameNum': nameNum,'msg':msg,
         'datas': datas,
         "charttype": charttype}), content_type="application/json")

def chart_bar(chartload,colnames,tumorload_chart,xcol=-1, ycol=-1, sorttype=None, typecol=-1,charttype=None,xtype=None,ytype=None,msg=None):
    # only Y
    if ycol >= 0 and xcol < 0:
        xdatas, ydatas, totaldatas = chartload.get_column_data(ycol=ycol, charttype=charttype)
        ycolnames = colnames[ycol].replace('\n', '')
        title = tumorload_chart.get_title(text="Anchordx chart for {}".format(ycolnames))
        tooltip = tumorload_chart.get_tooltip(trigger='item')
        legend = tumorload_chart.get_legend(ycolnames)
        nameNum = [ycolnames]
        yAxis = tumorload_chart.get_axis(name=ycolnames, type='category', data=ydatas)
        xAxis = tumorload_chart.get_axis(name="Count", type='value', position='bottom', nameLocation='middle',
                                         nameGap=25)

        datas = xdatas

    # only x
    elif ycol < 0 and xcol >= 0:
        xdatas, ydatas, totaldatas = chartload.get_column_data(xcol=xcol, charttype=charttype)

        xcolnames = colnames[xcol].replace('\n', '')
        title = tumorload_chart.get_title(text="Anchordx chart for {}".format(xcolnames))
        tooltip = tumorload_chart.get_tooltip(trigger='item')
        legend = tumorload_chart.get_legend(xcolnames)
        nameNum = [xcolnames]
        xAxis = tumorload_chart.get_axis(name=xcolnames, type='category', data=xdatas)
        yAxis = tumorload_chart.get_axis(name="Count", type='value', position='bottom',
                                         nameLocation='middle',
                                         nameGap=25)

        datas = ydatas

    # x and y
    elif xcol >= 0 and ycol >= 0:

        xdatas, ydatas, totaldatas, corr, cov = chartload.get_column_data(xcol=xcol, ycol=ycol, charttype=charttype, )
        if len(set(xdatas)) != len(set(ydatas)):
            return chart_scatter(colnames=colnames, chartload=chartload, tumorload_chart=tumorload_chart,
                                 msg='所选值不符合柱状图,自动转为散点图！',
                                 xcol=xcol, ycol=ycol, sorttype=sorttype, charttype='scatter', xtype=xtype,
                                 ytype=ytype)

        xcolnames = colnames[xcol].replace('\n', '')
        ycolnames = colnames[ycol].replace('\n', '')
        title1 = tumorload_chart.get_title(
            text="Anchordx chart for {} and {}".format(xcolnames, ycolnames), x='center')
        if corr and cov:
            title2 = tumorload_chart.get_title(
                text="相关系数: {}".format(corr),
                right='40%',
                top='3%',
            )
            title3 = tumorload_chart.get_title(
                text="协方差: {}".format(cov),
                right='20%',
                top='3%',
            )
            title = [title1, title2, title3]
        else:
            title = title1
        tooltip = tumorload_chart.get_tooltip(trigger='item')
        legend = tumorload_chart.get_legend(ycolnames)

        nameNum = [ycolnames]
        if all([isinstance(x, (str)) for x in xdatas]) and all([isinstance(x, (float, int)) for x in ydatas]):
            xAxis = tumorload_chart.get_axis(name=xcolnames, type='category', data=xdatas,
                                             position='bottom', nameLocation='middle', nameGap=25)
            yAxis = tumorload_chart.get_axis(type='value', name=ycolnames)
            datas = ydatas
        elif all([isinstance(x, (float, int)) for x in xdatas]) and all([isinstance(x, (str)) for x in ydatas]):
            xAxis = tumorload_chart.get_axis(type='value', name=xcolnames, position='bottom',
                                             nameLocation='middle', nameGap=25)
            yAxis = tumorload_chart.get_axis(name=ycolnames, type='category', position="top",
                                             data=ydatas)
            datas = xdatas
        else:
            xAxis = tumorload_chart.get_axis(name=xcolnames, data=xdatas, position='bottom', nameLocation='middle',
                                             nameGap=25)
            yAxis = tumorload_chart.get_axis(type='value', name=ycolnames)
            datas = ydatas
    else:
        title, tooltip, legend, xAxis, yAxis, totaldatas, nameNum, datas = '', '', '', '', '', '', '', '',

    return HttpResponse(json.dumps(
        {'title': title,
         'tooltip': tooltip,
         'legend': legend,
         'xAxis': xAxis,
         'yAxis': yAxis,
         'totaldatas': totaldatas,
         'nameNum': nameNum,
         "charttype": charttype,
         'datas': datas
         }, cls=MyEncoder),
        content_type="application/json")


def chart_boxplot(chartload,colnames,tumorload_chart,xcol=-1, ycol=-1, sorttype=None, typecol=-1,charttype=None,xtype=None,ytype=None,msg=None):
    # x and y
    if xcol >= 0 and ycol >= 0 and typecol < 0:

        try:
            datas, keys = chartload.get_column_data(xcol=xcol, ycol=ycol, sorttype=sorttype, charttype=charttype,
                                                    xtype=xtype, ytype=ytype)
        except:
            return HttpResponse(json.dumps(
                {'errors': u'不能生成图片,请设置数据类型,或检查x/y值,x/y轴不能同时为连续,不能同时为非连续,集合轴(unique<10),请重新选择'}),
                content_type="application/json")

        xcolnames = colnames[xcol].replace('\n', '')
        ycolnames = colnames[ycol].replace('\n', '')
        title = tumorload_chart.get_title(
            text="Anchordx boxplot chart for {} and {}".format(xcolnames, ycolnames))
        tooltip = tumorload_chart.get_tooltip(trigger='item')
        legend = tumorload_chart.get_legend(ycolnames)

        nameNum = [ycolnames]
        xdata = chartload.get_only_column_data(xcol)
        ydata = chartload.get_only_column_data(ycol)

        if all([isinstance(x, (str)) for x in xdata]) and all([isinstance(x, (str)) for x in ydata]):
            return HttpResponse(json.dumps(
                {'errors': u'不能生成图片,请设置数据类型,或请检查x/y值,x/y轴不能同时为连续,不能同时为非连续,集合轴(unique<10),请重新选择'}),
                content_type="application/json")

        if all([isinstance(x, (int, float)) for x in xdata]) and all([isinstance(x, (int, float)) for x in ydata]):
            return HttpResponse(json.dumps(
                {'errors': u'不能生成图片,请设置数据类型,或请检查x/y值,x/y轴不能同时为连续,不能同时为非连续,集合轴(unique<10),请重新选择'}),
                content_type="application/json")

        if all([isinstance(x, (str)) for x in xdata]):
            xAxis = tumorload_chart.get_axis(name=xcolnames, type='category', data=keys, boundaryGap=True,
                                             position='bottom', nameLocation='middle', nameGap=25,
                                             splitArea={'show': True}, splitLine={'show': False},
                                             axisLabel={'interval': 0})
            ifxAis = True
        elif all([isinstance(x, (float, int)) for x in xdata]):
            xAxis = tumorload_chart.get_axis(name=xcolnames, type='value', splitArea={'show': False},
                                             position='bottom', nameLocation='middle', nameGap=25)
            ifxAis = False
        else:
            xAxis = tumorload_chart.get_axis(name=xcolnames)
            ifxAis = False

        if all([isinstance(x, (str)) for x in ydata]):
            yAxis = tumorload_chart.get_axis(name=ycolnames, type='category', data=keys, boundaryGap=True,
                                             nameGap=30, splitArea={'show': True}, splitLine={'show': False})
            ifxAis = False
        elif all([isinstance(x, (float, int)) for x in ydata]):
            yAxis = tumorload_chart.get_axis(name=ycolnames, type='value', splitArea={'show': False})
            ifxAis = True
        else:
            yAxis = tumorload_chart.get_axis(name=ycolnames, splitArea={'show': False})
            ifxAis = True


    # x , y , type
    elif xcol >= 0 and typecol >= 0 and ycol >= 0:

        typenames = chartload.get_typenames(typecol=typecol)
        try:
            datas, keys = chartload.get_column_data(xcol=xcol, ycol=ycol, typecol=typecol, sorttype=sorttype,
                                                    charttype=charttype, xtype=xtype, ytype=ytype)
        except:
            return HttpResponse(json.dumps(
                {'errors': u'不能生成图片,请检查x/y值,x/y轴不能同时为连续,不能同时为非连续,集合轴(unique<10),请重新选择'}),
                content_type="application/json")
        xcolnames = colnames[xcol].replace('\n', '')
        ycolnames = colnames[ycol].replace('\n', '')
        tcolnames = colnames[typecol].replace('\n', '')
        title = tumorload_chart.get_title(
            text="Anchordx boxplot chart for {} and {} with type: {}".format(xcolnames, ycolnames, tcolnames))
        tooltip = tumorload_chart.get_tooltip(trigger='item')
        legend = tumorload_chart.get_legend(position=['right', 'center'], data=sorted(typenames), orient='vertical')

        nameNum = sorted(typenames)

        xdata = chartload.get_only_column_data(xcol)
        ydata = chartload.get_only_column_data(ycol)

        if all([isinstance(x, (str)) for x in xdata]) and all(
                [isinstance(x, (str)) for x in ydata]):
            return HttpResponse(json.dumps(
                {'errors': u'不能生成图片,请设置数据类型,或请检查x/y值,x/y轴不能同时为连续,不能同时为非连续,集合轴(unique<10),请重新选择'}),
                content_type="application/json")

        if all([isinstance(x, (int, float)) for x in xdata]) and all(
                [isinstance(x, (int, float)) for x in ydata]):
            return HttpResponse(json.dumps(
                {'errors': u'不能生成图片,请设置数据类型,或请检查x/y值,x/y轴不能同时为连续,不能同时为非连续,集合轴(unique<10),请重新选择'}),
                content_type="application/json")

        if all([isinstance(x, (str)) for x in xdata]):
            xAxis = tumorload_chart.get_axis(name=xcolnames, type='category', data=keys, boundaryGap=True,
                                             position='bottom', nameLocation='middle', nameGap=25,
                                             splitArea={'show': True}, splitLine={'show': False},
                                             axisLabel={'interval': 0})
            ifxAis = True
        elif all([isinstance(x, (float, int)) for x in xdata]):
            xAxis = tumorload_chart.get_axis(name=xcolnames, type='value', splitArea={'show': False},
                                             position='bottom', nameLocation='middle', nameGap=25)
            ifxAis = False
        else:
            xAxis = tumorload_chart.get_axis(name=xcolnames)

        if all([isinstance(x, (str)) for x in ydata]):
            yAxis = tumorload_chart.get_axis(name=ycolnames, type='category', data=keys, boundaryGap=True,
                                             nameGap=30, splitArea={'show': True}, splitLine={'show': False})
            ifxAis = False

        elif all([isinstance(x, (float, int)) for x in ydata]):
            yAxis = tumorload_chart.get_axis(name=ycolnames, type='value', splitArea={'show': False})
            ifxAis = True
        else:
            yAxis = tumorload_chart.get_axis(name=ycolnames, splitArea={'show': False})
            ifxAis = True
    else:
        return HttpResponse(json.dumps(
            {'errors': u'不能生成图片,X/Y轴必须选择！'}),
            content_type="application/json")

    return HttpResponse(json.dumps(
        {'title': title, 'tooltip': tooltip, 'legend': legend, 'xAxis': xAxis, 'yAxis': yAxis, 'ifxAis': ifxAis,
         'nameNum': nameNum, 'datas': datas, 'keys': keys,
         "charttype": charttype}), content_type="application/json")


# 绘制
@login_required()
def get_chart_datas(req):
    if req.method == 'POST':
        fileload = req.POST.get('fileload',None) or req.FILES.get('inputFile',None) or req.POST.get('inputFile',None)
        xcol = int(req.POST.get('xcol',None))
        ycol = int(req.POST.get('ycol',None))
        typecol = int(req.POST.get('typecol',None))
        excelsheet = int(req.POST.get('excelsheet',None))
        charttype = req.POST.get('charttype',None)
        sorttype = req.POST.get("sorttype",None)
        xtype = req.POST.get("xtype",None)
        ytype = req.POST.get("ytype",None)

        try:
            chartload = ChartLoadFile(fileload,excelsheet)
        except Exception as e:
            return HttpResponse(json.dumps({'errors': "file not accept,please check or contract administrator"}),
                                content_type="application/json")

        if fileload is None or fileload == '':
            return HttpResponse(json.dumps({'errors': "file not found,please check or contract administrator"}),
                                content_type="application/json")

        if (not xcol and not ycol) or (xcol<0 and ycol<0):
            return HttpResponse(json.dumps({'errors': "x轴或者y轴必须选择一个！"}),
                                content_type="application/json")

        colnames = chartload.get_all_cocolumnnames()
        tumorload_chart = Echart()

        if charttype == "scatter":
            return chart_scatter(colnames=colnames, chartload=chartload, tumorload_chart=tumorload_chart,typecol=typecol,
                                 xcol=xcol, ycol=ycol, sorttype=sorttype, charttype=charttype, xtype=xtype,
                                 ytype=ytype)

        if charttype == "bar":
            return chart_bar(colnames=colnames, chartload=chartload, tumorload_chart=tumorload_chart,
                                 typecol=typecol,
                                 xcol=xcol, ycol=ycol, sorttype=sorttype, charttype=charttype, xtype=xtype,
                                 ytype=ytype)

        if charttype == "boxplot":
            return chart_boxplot(colnames=colnames, chartload=chartload, tumorload_chart=tumorload_chart,
                             typecol=typecol,
                             xcol=xcol, ycol=ycol, sorttype=sorttype, charttype=charttype, xtype=xtype,
                             ytype=ytype)



