import os

PROJECT_ROOT = os.path.dirname(__file__)

DEBUG = True

STATIC_URL = '/static/'

STATICFILES_DIRS = (

    os.path.join(PROJECT_ROOT, 'static'),
)

STATICFILES_FINDERS = (
    'django.contrib.staticfiles.finders.FileSystemFinder',
    'django.contrib.staticfiles.finders.AppDirectoriesFinder',
)

print(STATICFILES_DIRS)