from django import forms
from django.contrib.auth.models import User
from tenkmop.models import Profile,Project


class UserForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ('first_name', 'last_name', 'email')

class ProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ('sex','company','address','title','phone','mobile','intro','img')

class ProjectForm(forms.ModelForm):
    class Meta:
        model = Project
        fields = ('name','type','state','created_time','progress','user')


