#coding:utf-8

from django import template

register = template.Library()

@register.filter(name='addattrs')
def addclass(value,args):
    styledict = {}
    for arg in args.split(","):
        style = arg.split("=")
        styledict[style[0]] = style[1]
    return value.as_widget(attrs=styledict)


