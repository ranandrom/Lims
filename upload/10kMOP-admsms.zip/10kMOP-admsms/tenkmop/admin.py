from django.contrib import admin
from tenkmop.models import *
from django import forms


class DataForm(forms.ModelForm):
    MY_CHOICES = []
    # projects = Project.objects.all()
    #
    # for project in  projects:
    #     MY_CHOICES.append((project.name, project.name))
    project = forms.ChoiceField(choices=set(MY_CHOICES))

class DataAdmin(admin.ModelAdmin):
    list_display = ('name', 'project', 'file', 'created_time')
    search_fields = ('name', 'project')
    list_filter = ('project','created_time')
    form = DataForm

class ProjectAdmin(admin.ModelAdmin):
    list_display = ('name', 'state', 'progress')
    search_fields = ('name', 'state')
    list_filter = ('name', 'state')

class TaskAdmin(admin.ModelAdmin):
    list_display = ('name', 'user', 'created_time')
    search_fields = ('name', 'user')
    list_filter = ('name', 'user')

class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'sex', 'company')
    search_fields = ('user', 'sex', 'company')
    list_filter = ('sex', 'company')


class SelfDataAdmin(admin.ModelAdmin):
    list_display = ('name', 'project', 'file', 'created_time')
    search_fields = ('name', 'project')
    list_filter = ('project','created_time')

admin.site.register(Project, ProjectAdmin)
admin.site.register(Profile, ProfileAdmin)
admin.site.register(Data, DataAdmin)
admin.site.register(SelfData, SelfDataAdmin)
admin.site.register(Task, TaskAdmin)