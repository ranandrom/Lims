from django.shortcuts import render, redirect, HttpResponse
from django.template.response import TemplateResponse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from tenkmop.forms import *
from django.contrib import messages
from tenkmop.models import *
from tenkmop.models import Data
import json
from tenkmop.utils.chartutils import format_excel, UploadCombine
from django.conf import settings
import pandas as pd
import datetime
import smtplib
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart


@login_required()
def index(req):
    username = req.user
    user = User.objects.get(username=username)
    projects = Project.objects.filter(user__username=username)
    projects_count = projects.count()
    u_data, u_data_count = [], 0
    for project in projects:
        u_ds = Data.objects.filter(project=project.name).order_by('-created_time')[:2]
        for u_d in u_ds:
            if u_d:
                u_data_count += 1
                u_data.append(u_d)
    self_datas = SelfData.objects.filter(user=req.user).order_by('-created_time')

    return render(req, 'index.html', locals())


# 修改密码
@login_required
def changepwd(req):
    if req.method == "POST":
        oldpassword = req.POST.get("oldpassword", None)
        newpassword = req.POST.get("newpassword", None)
        confirmnewpassword = req.POST.get("confirmnewpassword", None)
        if newpassword != confirmnewpassword:
            msg = "两次密码不相同！"
            return render(req,'changepwd.html',{'password_not_same': True,'msg':msg})
        user = authenticate(username=req.user.username, password=oldpassword)
        if user is not None and user.is_active:
            user.set_password(newpassword)
            user.save()
            logout(req)
            msg = "logout,changed password.密码已修改，请重新登陆"
            return render(req,'login.html', {'changepwd_success': True,'msg':msg})
        else:
            msg = "原密码不正确！"
            return render(req,'changepwd.html',{'oldpassword_is_wrong': True,'msg':msg})
    return render(req, 'changepwd.html')


@login_required
def get_chart(req,id):
    data = Data.objects.get(pk=id)
    file_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + '/media/' + data.file.name
    return render(req,'anchordxChart.html',{'file_path':file_path})


@login_required
def get_chart_self(req,id):
    data = SelfData.objects.get(pk=id)
    file_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + '/media/' + data.file
    return render(req,'anchordxChart.html',{'file_path':file_path})

@login_required
def get_chart_task(req,path):
    file_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + '/media/task_upload/' + req.user.username + '/' + path
    print(file_path)
    return render(req,'anchordxChart.html',{'file_path':file_path})

@login_required()
def profile(req):
    if req.method == 'POST':
        user_form = UserForm(req.POST, instance=req.user)
        profile_form = ProfileForm(req.POST, req.FILES,instance=req.user.profile)
        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            messages.success(req, ('Your profile was successfully updated!'))
            return redirect('/profile/')
        else:
            messages.error(req, ('Please correct the error below.'))
    else:
        user_form = UserForm(instance=req.user)
        profile_form = ProfileForm(instance=req.user.profile)
    return render(req, 'myprofile.html', {
        'user_form': user_form,
        'profile_form': profile_form
    })


@login_required()
def anchordxChart(req):
    user = req.user
    return render(req, 'anchordxChart.html', locals())

@login_required()
def methylation_data(req):
    user = req.user
    return render(req,'methylation_data.html',locals())


@login_required()
def my_projects(req):
    username = req.user
    user = User.objects.get(username=username)
    projects = Project.objects.filter(user=user)
    return render(req, 'myprojects.html', locals())

@login_required()
def mydatas(req):
    username = req.user
    user = User.objects.get(username=username)
    projects = Project.objects.filter(user=user)
    u_data, u_data_count = [], 0
    for project in projects:
        u_ds = Data.objects.filter(project=project.name).order_by('-created_time')[:2]
        for u_d in u_ds:
            if u_d:
                u_data_count += 1
                u_data.append(u_d)
    self_datas = SelfData.objects.filter(user=req.user).order_by('-created_time')
    return render(req,'mydatas.html',locals())


@login_required()
def myprojectsanddatas(req):
    username = req.user
    user = User.objects.get(username=username)
    projects = Project.objects.filter(user=user)
    projects_count = projects.count()
    u_data, u_data_count = [], 0
    for project in projects:
        u_ds = Data.objects.filter(project=project.name).order_by('-created_time')[:2]
        for u_d in u_ds:
            if u_d:
                u_data_count += 1
                u_data.append(u_d)
    self_datas = SelfData.objects.filter(user=req.user).order_by('-created_time')
    return render(req,'myprojectsanddatas.html',locals())


@login_required()
def analysis(req):
    user = req.user
    return render(req,'analysis.html',locals())


@login_required()
def datas(req):
    user = req.user
    return render(req,'datas.html',locals())


# @login_required()
# def data_detail(req, id):
#     user = req.user
#     data = Data.objects.get(pk=id)
#
#     dataFrame = pd.read_excel(data.file.path)
#
#     columns = dataFrame.columns
#     details = []
#     for row in dataFrame.iterrows():
#         index, data = row
#         details.append(data.tolist())
#
#     return render(req,'data_detail.html',locals())


@login_required()
def project_detail(req, project_id):
    project = Project.objects.get(pk=project_id)
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + '/media'
    with open(os.path.join(base_dir, project.white_file.name), 'r') as white_file:
        white_lines = white_file.readlines()
    white_dict = [json.loads(line) for line in white_lines]
    with open(os.path.join(base_dir, project.black_file.name), 'r') as black_file:
        black_lines = black_file.readlines()
    black_dict = [json.loads(line) for line in black_lines]
    project_datas = []
    for white in white_dict:
        temp_datas = []
        for black in black_dict:
            if list(white.keys())[0] == list(black.keys())[0]:
                temp_datas.append(list(white.keys())[0])
                temp_datas.append(len(list(white.values())[0]))
                temp_datas.append(len(list(black.values())[0]))
                try:
                    temp_datas.append((len(list(white.values())[0])/(len(list(white.values())[0]) + len(list(black.values())[0])))*100)
                except:
                    temp_datas.append(0)
                temp_datas.append([x[0] for x in list(white.values())[0]])
                temp_datas.append([x[0] for x in list(black.values())[0]])
        project_datas.append(temp_datas)
    return render(req, 'project_detail.html', {'project_datas':project_datas})


def userlogin(req,msg="login"):
    if req.method == "POST":
        username = req.POST.get('username')
        password = req.POST.get('password')
        remember_me = req.POST.get('remember_me')
        user = authenticate(username=username, password=password)
        if user is not None and user.is_active:
            if remember_me is None:
                req.session.set_expiry(0)
            login(req, user)
            return redirect('/')
        else:
            return render(req,'login.html',{"msg":"账号密码不正确"})
    return render(req,'login.html',{"msg":msg})


def userlogout(req):
    logout(req)
    msg = "logout"
    return render(req,'login.html',{"msg":msg})


def upload_tab(req):
    id = req.GET.get('id', None)
    data = Data.objects.get(pk=int(id))
    return render(req, 'upload_tab.html', locals())


def upload_file(req, id):
    up_file = req.FILES.get('upload_file', None)
    data = Data.objects.get(pk=int(id))
    print(data.file)
    if up_file:
        e = os.path.splitext(str(up_file))[1][1:]  # get .ext and remove dot
        strtime = datetime.datetime.now().strftime('%Y-%m-%d')
        uploaddir = 'media/self_upload/%s/%s/' % (req.user.username, strtime)
        if not os.path.exists(uploaddir):
            os.makedirs(uploaddir)
        with open('%s%s' % (uploaddir, up_file), 'wb+') as destination:
            for chunk in up_file.chunks():
                destination.write(chunk)

        filename = '{uploaddir}{up_file}'.format(uploaddir=uploaddir,up_file=up_file)
        up_file_path = 'self_upload/{user}/{data}/{up_file}'.format(user=req.user.username, data=strtime, up_file=up_file)
        if e == "xlsx" or e == "xls":
            format_excel(filename)

        file_path = 'self_upload/{}/{}/{}'.format(req.user.username, strtime, up_file)

        self_data = SelfData.objects.filter(name=up_file).first()
        if not self_data:
            SelfData(name=up_file, project=data.project, file_type=e,user=req.user,
                 size=str(round(os.stat(os.path.join(settings.MEDIA_DIR, file_path)).st_size / 1024 / 1024, 3)) + 'M',
                 file=file_path).save()
        else:
            self_data.created_time = datetime.datetime.now()
            self_data.size = str(round(os.stat(os.path.join(settings.MEDIA_DIR, file_path)).st_size / 1024 / 1024, 3)) + 'M'
            self_data.save()

        UploadCombine(user=req.user, origin_data=data, upload_file=up_file_path).combine_file()

    return TemplateResponse(req, 'redirect_template.html', {'redirect_url':'/my_datas'})

def dss_analysis_index(req):
    projects = Project.objects.filter(user__username=req.user.username).order_by('created_time')
    email_notify = req.user.email
    tasks = Task.objects.filter(user=req.user.username).order_by('-created_time')
    print([t.created_time for t in tasks])
    return render(req, 'dss_analysis_index.html', {'projects': projects, 'email_notify':email_notify, 'tasks':tasks})

def dss_analysis(req, project_id):
    project = Project.objects.get(pk=project_id)
    projects = Project.objects.filter(user__username=req.user.username)
    samples = sorted(project.samples.split(','))
    email_notify = req.user.email

    return render(req, 'dss_analysis.html', {'project': project, 'projects': projects, 'samples':samples, 'email_notify':email_notify})


def dss_analysis_result(req, task_id):
    task = Task.objects.get(pk=task_id)
    file1_name = task.file1.name.split('/')[-1]
    file2_name = task.file2.name.split('/')[-1]
    return render(req, 'dss_analysis_result.html', {'task': task, 'file1_name':file1_name, 'file2_name':file2_name,},)



def admsms(req):
    # project = Project.objects.get(pk=project_id)
    # projects = Project.objects.filter(user__username=req.user.username)
    # samples = sorted(project.samples.split(','))
    # email_notify = req.user.email

    return render(req, 'admsms.html')


def send_mail(to_addrs, msg):
    # Email地址和口令:
    from_addr = 'hpc_server@anchordx.com'
    password = 'AD20151212abc'
    # 输入SMTP服务器地址:
    smtp_server = 'smtp.exmail.qq.com'
    # 输入收件人地址:
    msg['From'] = from_addr
    msg['To'] = ", ".join(to_addrs)
    server = smtplib.SMTP_SSL(smtp_server, 465)  #SSL
    # server.set_debuglevel(1)
    server.login(from_addr, password)
    server.sendmail(from_addr, to_addrs, msg.as_string())
    server.quit()


def post_dss_analysis(req):
    project_id = req.POST.get('project', None)
    sampleID = req.POST.getlist('sampleID', None)
    sampleID2 = req.POST.getlist('sampleID2', None)
    email_notify_option = req.POST.get('email_notify_option', None)
    email_notify = req.POST.get('email_notify', None)
    diff = req.POST.get('diff', None)
    p = req.POST.get('p', None)

    msg = MIMEMultipart('mixed')

    group_1 = "group_1_" + str(int(time.time()))
    group_2 = "group_2_" + str(int(time.time()))

    project = Project.objects.get(pk=int(project_id))
    task_name = '{project}_dss_{rand}'.format(project=project.name,rand=datetime.datetime.now().strftime('%Y%m%d%H%M%S'))

    if not Task.objects.filter(name=task_name, user=req.user.username,
                               samples_1=",".join(sampleID), samples_2=",".join(sampleID2), diff=diff, p=p):
        task = Task(name=task_name, user=req.user.username, samples_1=",".join(sampleID), samples_2=",".join(sampleID2), diff=diff, p=p)
        task.save()

        msg['Subject'] = "DSS_ANALYSIS"
        text_dict = {'project': project.name, 'sampleID': sampleID, 'task_id': task.id,
                     'sampleID2': sampleID2, 'email_notify_option': email_notify_option,
                     'email_notify': email_notify, 'diff': diff, 'p': p,
                     'group_1': group_1, 'group_2': group_2, 'task_name':task_name}

        text = json.dumps(text_dict)

        content = MIMEText(text, 'plain')
        msg.attach(content)

        # send_mail(to_addrs=['yaolin_fu@anchordx.com'],msg=msg)
        send_mail(to_addrs=['hpc_server@anchordx.com'], msg=msg)

        req.user.email = email_notify
        req.user.save()

        return redirect('dss_analysis_index')

    else:
        return redirect('dss_analysis_index')



