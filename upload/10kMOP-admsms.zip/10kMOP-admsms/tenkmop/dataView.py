from tenkmop.models import Project, Data, Task
from tenkmop.utils.serializers import DataSerializer, UserSerializer, ProjectSerializer, TaskSerializer
from django.contrib.auth.models import User
from rest_framework import permissions
from tenkmop.utils.permissions import IsOwnerOrReadOnly
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.reverse import reverse
from rest_framework import viewsets
from rest_framework.parsers import FormParser, MultiPartParser


@api_view(('GET',))
def api_root(request, format=None):
    return Response({
        'users': reverse('user-list', request=request, format=format),
        'snippets': reverse('snippet-list', request=request, format=format)
    })


class DataViewSet(viewsets.ModelViewSet):
    """
    This viewset automatically provides `list`, `create`, `retrieve`,
    `update` and `destroy` actions.

     """
    queryset = Data.objects.all()
    serializer_class = DataSerializer
    permission_classes = (permissions.IsAuthenticatedOrReadOnly,
                          IsOwnerOrReadOnly,)
    parser_classes = (MultiPartParser, FormParser,)


    def perform_create(self, serializer):
        serializer.save(file=self.request.data.get('file'))


class TaskViewSet(viewsets.ModelViewSet):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer
    permission_classes = (permissions.IsAuthenticatedOrReadOnly,
                          IsOwnerOrReadOnly,)
    parser_classes = (MultiPartParser, FormParser,)

    def perform_create(self, serializer):
        serializer.save(img1=self.request.data.get('img1'),
                        img2=self.request.data.get('img2'),
                        file1=self.request.data.get('file1'),
                        file2=self.request.data.get('file2'),
                        name=self.request.data.get('name'),
                        state=self.request.data.get('state'),
                        )



class ProjectViewSet(viewsets.ModelViewSet):
    """
    This viewset automatically provides `list` and `detail` actions.
    """
    queryset = Project.objects.all()
    serializer_class = ProjectSerializer
    permission_classes = (permissions.IsAuthenticatedOrReadOnly,
                          IsOwnerOrReadOnly,)
    parser_classes = (MultiPartParser, FormParser,)

    def perform_create(self, serializer):
        try:
            serializer.save(progress=self.request.data.get('progress'),
                            name=self.request.data.get('name'),
                            white=self.request.data.get('white'),
                            black=self.request.data.get('black'),
                            post_flag=self.request.data.get('post_flag'),
                            white_file=self.request.data.get('white_file'),
                            samples=self.request.data.get('samples'),
                            black_file=self.request.data.get('black_file'))
        except Exception as e:
            print(e)


class UserViewSet(viewsets.ReadOnlyModelViewSet):
    """
    This viewset automatically provides `list` and `detail` actions.
    """
    queryset = User.objects.all()
    serializer_class = UserSerializer


