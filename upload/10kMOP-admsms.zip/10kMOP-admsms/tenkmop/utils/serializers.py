from rest_framework import serializers
from tenkmop.models import Data, Project, Task
from django.contrib.auth.models import User


class DataSerializer(serializers.HyperlinkedModelSerializer):
    # user = serializers.ReadOnlyField(source='user.username')
    class Meta:
        model = Data
        fields = ('name', 'size','file','project')

class TaskSerializer(serializers.HyperlinkedModelSerializer):
    # user = serializers.ReadOnlyField(source='user.username')
    class Meta:
        model = Task
        fields = ('name', 'state', 'img1', 'img2','file1','file2')

class ProjectSerializer(serializers.HyperlinkedModelSerializer):
    # user = serializers.HyperlinkedRelatedField(many=True, view_name='user-detail', read_only=True)
    class Meta:
        model = Project
        fields = ('name', 'type','state', 'progress', 'post_flag','white', 'black', 'black_file', 'white_file', 'samples')


class UserSerializer(serializers.HyperlinkedModelSerializer):
    # data_user = serializers.HyperlinkedRelatedField(many=True, view_name='data-detail', read_only=True)
    project_user = serializers.HyperlinkedRelatedField(many=True, view_name='project-detail', read_only=True)

    class Meta:
        model = User
        fields = ('url', 'username', 'project_user')