#coding:utf8
import os
import pandas as pd
from pandas import Series,DataFrame
from tenkmop.utils.echart import *
import numpy as np
import datetime
from tenkmop.models import SelfData
from django.core.files import File
from django.conf import settings



class MyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return super(MyEncoder, self).default(obj)


# 格式化excel表 删除空行以及以 # 号注释的行
def format_excel(filename):
    xls = pd.ExcelFile(filename)  # 读入excel
    writer = pd.ExcelWriter(filename)  # 写入excel
    for sheet in xls.sheet_names:
        datas = xls.parse(sheetname=sheet)
        ignorerow = []
        datas = datas.dropna(how='all').reset_index(drop=True)  # 删除所有空行
        for i in datas.index.values:
            if str(datas[datas.columns[0]][i]).strip().startswith('#') or str(
                    datas[datas.columns[0]][i]).strip().startswith('＃'):
                ignorerow.append(i)  # 忽略的行数
        datas = datas.drop(datas.index[ignorerow]).reset_index(drop=True)  # 删除以 # 号注释的行
        if str(datas.columns[0]).strip().startswith('#') or str(datas.columns[0]).strip().startswith('＃'):  # 第一行判断
            datas.columns = datas.iloc[0].fillna('UnknowColumn')
            datas = datas.drop(datas.index[0]).reset_index(drop=True)
        datas.to_excel(writer, sheet, index=False)
    writer.save()

#ChartLoadFile
class ChartLoadFile(object):
    def __init__(self, filename,sheetname=-1):
        e = os.path.splitext(filename)[1][1:]  # get .ext and remove dot
        if e == "xlsx" or e == "xls":
            xls = pd.ExcelFile(filename)
            self.datas = xls.parse(xls.sheet_names[sheetname])
        elif e == "csv" or e == "txt":
            self.datas = pd.read_csv(filename,  sep='\t', encoding="utf-8")
        elif e == "json":
            self.datas = pd.read_json(filename,  encoding="utf-8")

    def get_sheet_names(self, filename):
        e = os.path.splitext(filename)[1][1:]  #get .ext and remove dot
        if e == "xlsx" or e == "xls":
            xls = pd.ExcelFile(filename)
            return xls.sheet_names
        else:
            return []

    def get_all_cocolumnnames(self):
        return self.datas.columns.tolist()

    # 如果出现相同列名，就存入dataframe
    def get_columnnames(self):
        columnnametypes, dataframe = [], []
        for i in range(len(self.datas.columns)):
            col = self.datas.columns[i]
            try:
                dtype = self.datas[col].dtype
                columnnametypes.append([i, col, '{}'.format(dtype)])
            except:
                dataframe.append(col)
        return columnnametypes, dataframe

    def get_type_names(self):
        typeindex= []
        columnnames,dataframe = self.get_columnnames()
        for colindex in range(len(columnnames)):
            try:
                if len(self.datas[self.datas.columns[columnnames[colindex][0]]].value_counts().tolist()) < 10:
                    typeindex.append(colindex)
            except:
                pass
        return typeindex

    # get all type name
    def get_typenames(self,typecol):
        typenames = sorted(list(set(self.datas[self.datas.columns[typecol]].tolist())))
        try:
            return [str(name) for name in typenames]
        except :
            return typenames

    # only get the special column data
    def get_only_column_data(self,col):
        return self.datas[self.datas.columns[col]].tolist()

    def fill_null_with_col(self, col, changetype):
        if self.datas[self.datas.columns[col]].dtype == np.float or self.datas[
            self.datas.columns[col]].dtype == np.int \
                or self.datas[self.datas.columns[col]].dtype == np.long:
            if changetype == 'type' or changetype == 'value':
                self.datas[self.datas.columns[col]] = self.datas[self.datas.columns[col]].astype(float)
                self.datas[self.datas.columns[col]] = self.datas[self.datas.columns[col]].fillna(0)
            elif changetype == 'category':
                self.datas[self.datas.columns[col]] = self.datas[self.datas.columns[col]].astype(str)
                self.datas[self.datas.columns[col]] = self.datas[self.datas.columns[col]].fillna('nan')
            else:
                self.datas[self.datas.columns[col]] = self.datas[self.datas.columns[col]].fillna(0)
        elif self.datas[self.datas.columns[col]].dtype == np.str or self.datas[self.datas.columns[col]].dtype == np.object:
            if changetype == 'value':
                self.datas[self.datas.columns[col]] = self.datas[self.datas.columns[col]].astype(float)
                self.datas[self.datas.columns[col]] = self.datas[self.datas.columns[col]].fillna(0)
            elif changetype == 'type' or changetype == 'category':
                self.datas[self.datas.columns[col]] = self.datas[self.datas.columns[col]].astype(str)
                self.datas[self.datas.columns[col]] = self.datas[self.datas.columns[col]].fillna('nan')
            else:
                self.datas[self.datas.columns[col]] = self.datas[self.datas.columns[col]].fillna('nan')
        else:
            self.datas[self.datas.columns[col]] = self.datas[[self.datas.columns[col]]].fillna(0)

    # 取得datas
    def get_column_data(self, xcol=-1, ycol=-1, sorttype=-1, typecol=-1,charttype=None, xtype=None,ytype=None):
        # 如果unique值少于10，转字符串格式
        if xcol >=0 :
            self.xdatas = self.get_only_column_data(xcol)
            if len(set(self.xdatas)) < 10:
                if not all([isinstance(x, (str)) for x in self.datas[self.datas.columns[xcol]].tolist()]):
                    self.datas[self.datas.columns[xcol]] = self.datas[self.datas.columns[xcol]].astype(str)
        if ycol >= 0 :
            self.ydatas = self.get_only_column_data(ycol)
            if len(set(self.ydatas)) < 10:
                if not all([isinstance(x, (str)) for x in self.datas[self.datas.columns[ycol]].tolist()]):
                    self.datas[self.datas.columns[ycol]] = self.datas[self.datas.columns[ycol]].astype(str)
        #处理空值,填充nan或0
        if xtype:
            self.fill_null_with_col(col=xcol, changetype=xtype)
        if ytype:
            self.fill_null_with_col(col=ycol, changetype=ytype)

        if charttype == 'scatter':
            # 没有选择类型轴
            if typecol < 0:
                if xcol<0 and ycol >=0:
                    # 仅选择了Y轴，并根据y升序(y)
                    df = self.datas[[self.datas.columns[ycol]]]
                    if sorttype == 'ay':
                        df = df.sort_values(by=self.datas.columns[ycol], ascending=True)
                        df['order'] = range(len(df.index.values))
                        df = df[['order', self.datas.columns[ycol]]]
                        return list(list(x) for x in zip(*(df[x].values.tolist() for x in df.columns)))
                        # 选择了Y轴，并根据Y降序
                    elif sorttype == 'dy':
                        df = df.sort_values(by=self.datas.columns[ycol], ascending=False)
                        df['order'] = range(len(df.index.values))
                        df = df[['order', self.datas.columns[ycol]]]
                        return list(list(x) for x in zip(*(df[x].values.tolist() for x in df.columns)))
                        # Y不排序
                    else:
                        df['order'] = df.index.values
                        df = df[['order', self.datas.columns[ycol]]]
                        return list(list(x) for x in zip(*(df[x].values.tolist() for x in df.columns)))
                #x
                elif xcol>=0 and ycol<0:
                    # 选择了x轴，并根据x升序
                    df = self.datas[[self.datas.columns[xcol]]]
                    if sorttype == 'ay':
                        df = df.sort_values(by=self.datas.columns[xcol], ascending=True)
                        df['order'] = range(len(df.index.values))
                        df = df[[self.datas.columns[xcol],'order']]
                        return list(list(x) for x in zip(*(df[x].values.tolist() for x in df.columns)))
                        # 选择了Y轴，并根据Y降序
                    elif sorttype == 'dy':
                        df = df.sort_values(by=self.datas.columns[xcol], ascending=False)
                        df['order'] = range(len(df.index.values))
                        df = df[[ self.datas.columns[xcol],'order']]
                        return list(list(x) for x in zip(*(df[x].values.tolist() for x in df.columns)))
                        # Y不排序
                    else:
                        df['order'] = df.index.values
                        df = df[[self.datas.columns[xcol],'order']]
                        return list(list(x) for x in zip(*(df[x].values.tolist() for x in df.columns)))

                #选择了X轴和Y轴
                elif xcol>=0 and ycol>=0:
                    #选择了根据x升序
                    df = self.datas[[self.datas.columns[xcol], self.datas.columns[ycol]]]
                    try:
                        corr = df[self.datas.columns[xcol]].corr(df[self.datas.columns[ycol]])# 相关系数
                        cov = df[self.datas.columns[xcol]].cov(df[self.datas.columns[ycol]])# 协方差
                    except:
                        corr = None
                        cov = None
                    return list(list(x) for x in zip(*(df[x].values.tolist() for x in df.columns))),corr,cov
                #no select ,error
                else:
                    return []
            #选择了类型轴
            else:
                types = sorted(list(set(self.datas[self.datas.columns[typecol]])))
                #x,y,type
                if xcol>=0 and ycol>=0:
                    df = self.datas[[self.datas.columns[xcol], self.datas.columns[ycol],self.datas.columns[typecol]]]
                    try:
                        corr = df[self.datas.columns[xcol]].corr(df[self.datas.columns[ycol]])  # 相关系数
                        cov = df[self.datas.columns[xcol]].cov(df[self.datas.columns[ycol]])  # 协方差
                    except:
                        corr = None
                        cov = None
                    typedata = []
                    for t in types:
                        df = DataFrame(self.datas.loc[self.datas[self.datas.columns[typecol]] == t])[[
                            self.datas.columns[xcol], self.datas.columns[ycol], self.datas.columns[typecol]]]
                        typedata.append(list(list(x) for x in zip(*(df[x].values.tolist() for x in df.columns))))
                    return typedata, corr, cov
                #x,type
                elif xcol>=0 and ycol<0:

                    if xcol == typecol :
                        df = self.datas[[self.datas.columns[xcol]]]
                    else:
                        df = self.datas[[self.datas.columns[xcol], self.datas.columns[typecol]]]
                    if sorttype == 'ax':
                        df = df.sort_values(by=self.datas.columns[xcol], ascending=True)
                        df['order'] = range(len(df.index.values))
                        # 选择了x轴，并根据x降序
                    elif sorttype == 'dx':
                        df = df.sort_values(by=self.datas.columns[xcol], ascending=False)
                        df['order'] = range(len(df.index.values))
                    # 不排序
                    else:
                        df['order'] = range(len(df.index.values))


                    typedata = []
                    if xcol == typecol :
                        df = df[[self.datas.columns[xcol], 'order']]
                    else:
                        df = df[[self.datas.columns[xcol], 'order', self.datas.columns[typecol]]]

                    for t in types:
                        if xcol == typecol:
                            df2 = DataFrame(df.loc[df[self.datas.columns[xcol]] == t])[[
                                self.datas.columns[xcol], 'order']]
                        else:
                            df2 = DataFrame(df.loc[df[self.datas.columns[typecol]] == t])[[
                                self.datas.columns[xcol], 'order', self.datas.columns[typecol]]]
                        typedata.append(map(list, df2.values))
                    return typedata
                #y,type
                elif xcol<0 and ycol>=0:
                    if ycol == typecol:
                        df = self.datas[[self.datas.columns[ycol]]]
                    else:
                        df = self.datas[[self.datas.columns[ycol], self.datas.columns[typecol]]]

                    # 选择了Y轴，并根据y升序(y)
                    if sorttype == 'ay':
                        df = df.sort_values(by=self.datas.columns[ycol], ascending=True)
                        df['order'] = range(len(df.index.values))

                    # 选择了Y轴，并根据Y降序
                    elif sorttype == 'dy':
                        df = df.sort_values(by=self.datas.columns[ycol], ascending=False)
                        df['order'] = range(len(df.index.values))

                    # 不排序
                    else:
                        df['order'] = range(len(df.index.values))

                    typedata = []
                    if ycol == typecol:
                        df = df[['order', self.datas.columns[ycol]]]
                    else:
                        df = df[['order', self.datas.columns[ycol], self.datas.columns[typecol]]]

                    for t in types:
                        if ycol == typecol:
                            df2 = DataFrame(df.loc[df[self.datas.columns[ycol]] == t])[[
                                'order', self.datas.columns[ycol]]]
                        else:
                            df2 = DataFrame(df.loc[df[self.datas.columns[typecol]] == t])[[
                                'order', self.datas.columns[ycol], self.datas.columns[typecol]]]
                        typedata.append(map(list, df2.values))
                    return typedata
                else:
                    return []

        if charttype == 'boxplot':
            if xcol>=0 and ycol>=0 and typecol<0:
                if all([isinstance(x, (str)) for x in self.datas[self.datas.columns[xcol]].tolist()]) and not all([isinstance(x, (str)) for x in self.datas[self.datas.columns[ycol]].tolist()]):
                    grouped = self.datas.groupby(self.datas[self.datas.columns[xcol]])
                    dictlist = {}
                    for d, f in grouped:
                        dictlist[d] = f[self.datas.columns[ycol]].tolist()
                    values = [(k, dictlist[k]) for k in sorted(dictlist.keys())]
                    keys = sorted(dictlist.keys())
                    data = []
                    for v in values:
                        data.append(v[1])
                    return [data], keys
                elif not all([isinstance(x, (str)) for x in self.datas[self.datas.columns[xcol]].tolist()]) and all([isinstance(x, (str)) for x in self.datas[self.datas.columns[ycol]].tolist()]):
                    grouped = self.datas.groupby(self.datas[self.datas.columns[ycol]])
                    dictlist = {}
                    for d, f in grouped:
                        dictlist[d] = f[self.datas.columns[xcol]].tolist()
                    values = [(k, dictlist[k]) for k in sorted(dictlist.keys())]
                    keys = sorted(dictlist.keys())
                    data = []
                    for v in values:
                        data.append(v[1])
                    return [data], keys
                else:
                    return {}
            elif xcol>=0 and ycol>=0 and typecol>=0:
                if all([isinstance(x, (str)) for x in self.datas[self.datas.columns[xcol]].tolist()]) and not all([isinstance(x, (str)) for x in self.datas[self.datas.columns[ycol]].tolist()]):
                    # 如果type 和 x 一样,则只根据type进行group,对应填补空list
                    if typecol == xcol:
                        grouped = self.datas.groupby([self.datas.columns[typecol]])
                        dictlist = {}
                        for k, v in grouped:
                            dictlist[k] = v[self.datas.columns[ycol]].tolist()
                        values = []
                        typekeys = sorted(set(dictlist.keys()))
                        groupkeys = sorted(set(dictlist.keys()))
                        for setk in typekeys:
                            valuedict = {}
                            for k in dictlist.keys():
                                if k == setk:
                                    valuedict[k] = dictlist[k]
                            tempkeys = [g for g in groupkeys]
                            for key in valuedict.keys():
                                if key in groupkeys:
                                    tempkeys.remove(key)
                            if len(tempkeys):
                                for tempkey in tempkeys:
                                    valuedict[tempkey] = []
                            values.append(valuedict)
                        data = []
                        for v in values:
                            value = [(k, v[k]) for k in sorted(v.keys())]
                            d = []
                            for v in value:
                                d.append(v[1])
                            data.append(d)
                        return data, groupkeys
                    grouped = self.datas.groupby([self.datas.columns[typecol], self.datas.columns[xcol]])
                    dictlist = {}
                    for k, v in grouped:
                        dictlist[k] = v[self.datas.columns[ycol]].tolist()
                    typekeys = []
                    groupkeys = []
                    for k in dictlist.keys():
                        typekeys.append(k[0])
                    for k in dictlist.keys():
                        groupkeys.append(k[1])
                    typekeys = sorted(set(typekeys))
                    groupkeys = sorted(set(groupkeys))
                    values = []
                    for setk in typekeys:
                        valuedict = {}
                        for k in dictlist.keys():
                            if k[0] == setk:
                                valuedict[k] = dictlist[k]
                        tempkeys = [g for g in groupkeys]
                        for key in valuedict.keys():
                            if key[1] in groupkeys:
                                tempkeys.remove(key[1])
                        if len(tempkeys):
                            for tempkey in tempkeys:
                                valuedict[(k[0], tempkey)] = []
                        values.append(valuedict)
                    data = []
                    for v in values:
                        value = [(k, v[k]) for k in sorted(v.keys())]
                        d = []
                        for v in value:
                            d.append(v[1])
                        data.append(d)
                    return data, groupkeys
                elif not all([isinstance(x, (str)) for x in self.datas[self.datas.columns[xcol]].tolist()]) and all([isinstance(x, (str)) for x in self.datas[self.datas.columns[ycol]].tolist()]):
                    if typecol == ycol:
                        grouped = self.datas.groupby([self.datas.columns[typecol]])
                        dictlist = {}
                        for k, v in grouped:
                            dictlist[k] = v[self.datas.columns[xcol]].tolist()
                        values = []
                        typekeys = sorted(set(dictlist.keys()))
                        groupkeys = sorted(set(dictlist.keys()))
                        for setk in typekeys:
                            valuedict = {}
                            for k in dictlist.keys():
                                if k == setk:
                                    valuedict[k] = dictlist[k]
                            tempkeys = [g for g in groupkeys]
                            for key in valuedict.keys():
                                if key in groupkeys:
                                    tempkeys.remove(key)
                            if len(tempkeys):
                                for tempkey in tempkeys:
                                    valuedict[tempkey] = []
                            values.append(valuedict)
                        data = []
                        for v in values:
                            value = [(k, v[k]) for k in sorted(v.keys())]
                            d = []
                            for v in value:
                                d.append(v[1])
                            data.append(d)
                        return data, groupkeys
                    grouped = self.datas.groupby([self.datas.columns[typecol], self.datas.columns[ycol]])
                    dictlist = {}
                    for k, v in grouped:
                        dictlist[k] = v[self.datas.columns[xcol]].tolist()
                    typekeys = []
                    groupkeys = []
                    for k in dictlist.keys():
                        typekeys.append(k[0])
                    for k in dictlist.keys():
                        groupkeys.append(k[1])
                    typekeys =  sorted(set(typekeys))
                    groupkeys = sorted(set(groupkeys))
                    values = []
                    for setk in typekeys:
                        valuedict = {}
                        for k in dictlist.keys():
                            if k[0] == setk:
                                valuedict[k] = dictlist[k]
                        tempkeys = [g for g in groupkeys]
                        for key in valuedict.keys():
                            if key[1] in groupkeys:
                                tempkeys.remove(key[1])
                        if len(tempkeys):
                            for tempkey in tempkeys:
                                valuedict[(k[0], tempkey)] = []
                        values.append(valuedict)
                    data = []
                    for v in values:
                        value = [(k, v[k]) for k in sorted(v.keys())]
                        d = []
                        for v in value:
                            d.append(v[1])
                        data.append(d)

                    return data, groupkeys

                else:
                    return {}

        if charttype == 'bar':
            # 没有选择类型轴
            if typecol < 0:
                if xcol < 0 and ycol >= 0:
                    # 仅选择了Y轴，并根据y升序(y)
                    df = self.datas[[self.datas.columns[ycol]]]
                    # df = df.sort_values(by=self.datas.columns[ycol], ascending=True)
                    df[self.datas.columns[ycol]] = df[self.datas.columns[ycol]].astype(str)
                    df[self.datas.columns[ycol]] = df[self.datas.columns[ycol]].fillna('nan')
                    df['order'] = range(len(df.index.values))
                    totaldatas = df.groupby(self.datas.columns[ycol]).size().to_dict()
                    xdata,ydata = [], []
                    for k in sorted(totaldatas.items(), key=lambda x: x[0]):
                        xdata.append(k[1])
                        ydata.append(k[0])
                    return xdata,ydata, totaldatas


                elif xcol >= 0 and ycol < 0:
                    # 选择了x轴，并根据x升序
                    df = self.datas[[self.datas.columns[xcol]]]
                    df[self.datas.columns[xcol]] = df[self.datas.columns[xcol]].astype(str)
                    df[self.datas.columns[xcol]] = df[self.datas.columns[xcol]].fillna('nan')
                    df['order'] = range(len(df.index.values))
                    totaldatas = df.groupby(self.datas.columns[xcol]).size().to_dict()
                    xdata, ydata = [], []
                    for k in sorted(totaldatas.items(), key=lambda x: x[0]):
                        xdata.append(k[0])
                        ydata.append(k[1])
                    return xdata, ydata, totaldatas

                # 选择了X轴和Y轴
                elif xcol >= 0 and ycol >= 0:
                    # 选择了根据x升序
                    self.fill_null_with_col(col=xcol, changetype='type')
                    self.fill_null_with_col(col=ycol, changetype='type')
                    df = self.datas[[self.datas.columns[xcol], self.datas.columns[ycol]]]
                    df = df.sort_values(by=self.datas.columns[xcol], ascending=True)
                    xdata, ydata = [], []

                    xdata = df[self.datas.columns[xcol]].tolist()
                    ydata = df[self.datas.columns[ycol]].tolist()
                    totaldatas = dict(zip(xdata, ydata))
                    try:
                        corr = df[self.datas.columns[xcol]].corr(df[self.datas.columns[ycol]])  # 相关系数
                        cov = df[self.datas.columns[xcol]].cov(df[self.datas.columns[ycol]])  # 协方差
                    except:
                        corr = None
                        cov = None
                    return xdata, ydata, totaldatas,corr,cov
                # no select ,error
                else:
                    return []




class Echart(object):
    def __init__(self,title=""):
        self.title = title


    def get_series(self,type,name,data,**kwargs):
        return Series(type=type, name=name, data=data,**kwargs).json


    def get_serieslist(self,type,name,data,**kwargs):
        serieslist = []
        for ty in range(len(name)):
            series = Series(type=type, name=name[ty], data=data[ty],**kwargs)
            serieslist.append(series.json)
        return serieslist

    def get_tooltip(self,trigger='axis', **kwargs):
        return Tooltip(trigger, **kwargs).json

    def get_toolbox(self,orient='horizontal', position=None, **kwargs):
        return Toolbox(orient, position, **kwargs).json

    def get_legend(self, data, orient='horizontal', position=None, **kwargs):
        return Legend( data, orient, position, **kwargs).json

    def get_axis(self, type='', position='bottom', name='', data=None, **kwargs):
        return Axis(type, position, name, data, **kwargs).json

    def get_title(self,text="",**kwargs):
        return Ttile(text,**kwargs).json


class UploadCombine(object):

    def __init__(self,user,origin_data,upload_file):
        self.user = user
        self.origin_data = origin_data
        self.upload_file = upload_file

        # self.base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    def combine_file(self):
        origin_datas = pd.read_excel(self.origin_data.file.path)
        upload_datas = pd.read_excel(os.path.join(settings.MEDIA_DIR,self.upload_file))


        for col in upload_datas.columns:
            if col.lower() == 'Sample ID'.lower() or col.lower() == 'Sample_ID'.lower():
                pass
            else:
                upload_datas = upload_datas.rename(columns={'{old_name}'.format(old_name=col): 'upload_{new_name}'.format(new_name=col)})

        file_path = os.path.join(settings.MEDIA_DIR+ "/self_upload/{user}/{filename}".format(
            user=self.user,
            filename='{upload}_combine_{name}.xlsx'.format(
                upload=os.path.splitext(self.upload_file.split('/')[-1])[0],
                name=self.origin_data.name)))
        writer = pd.ExcelWriter(file_path)


        combine_datas = pd.merge(origin_datas,upload_datas, left_on='Sample ID', right_on='Sample ID')
        combine_datas.to_excel(writer, sheet_name='Sheet1', index=False)

        writer.save()


        self_data = SelfData.objects.filter(name='{upload}_combine_{name}.xlsx'.format(
                upload=os.path.splitext(self.upload_file.split('/')[-1])[0],
                name=self.origin_data.name)).first()
        if not self_data:
            data = SelfData()

            data.project = self.origin_data.project
            data.name = '{upload}_combine_{name}.xlsx'.format(
                    upload=os.path.splitext(self.upload_file.split('/')[-1])[0],
                    name=self.origin_data.name)
            data.size = str(round(os.stat(file_path).st_size / 1024 / 1024, 3)) + 'M'
            data.file_type = os.path.splitext(file_path)[1][1:]
            data.user = self.user
            data.file = "self_upload/{user}/{filename}".format(
                user=self.user,
                filename='{upload}_combine_{name}.xlsx'.format(
                    upload=os.path.splitext(self.upload_file.split('/')[-1])[0],
                    name=self.origin_data.name))

            data.save()
        else:
            self_data.size = str(round(os.stat(file_path).st_size / 1024 / 1024, 3)) + 'M'
            self_data.save()
