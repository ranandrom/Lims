from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.dispatch import receiver
from django.db.models.signals import post_save
# from notifications.signals import notify
import os
import datetime
import time
import random
from django.core.files.base import File
from django.db.models.fields.related import ForeignKey


# 分页查询工具
class Pages(object):
    def __init__(self, count, current_page=1, list_rows=100):
        self.total = count
        self._current = current_page
        self.size = list_rows
        self.pages = self.total // self.size + (1 if self.total % self.size else 0)

        if (self.pages == 0) or (self._current < 1) or (self._current > self.pages):
            self.start = 0
            self.end = 0
            self.index = 1
        else:
            self.start = (self._current - 1) * self.size
            self.end = self.size + self.start
            self.index = self._current
        self.prev = self.index - 1 if self.index > 1 else self.index
        self.next = self.index + 1 if self.index < self.pages else self.index

# 上传文件目录
def upload_path_txt(instance, old_filename):
    try:
        project = instance.name.split('_')[1]
    except:
        project = instance.name

    file_path = 'project_txt/{project}/{old_filename}'.format(
        project=project,
        old_filename=old_filename)
    return file_path

# 上传文件目录
def upload_path(instance, old_filename):
    extension = os.path.splitext(old_filename)[1].lower()
    file_name = os.path.splitext(old_filename)[0]
    today = datetime.datetime.today()
    # timestamp = int(time.time())
    # rand = random.randint(1,10000)
    try:
        project = instance.name.split('_')[1]
    except:
        project = instance.name


    file_path = 'upload/{project}/{date_time}/{file_name}{extension}'.format(
        project=project,
        date_time=datetime.datetime.now().strftime('%Y-%m-%d'),
        file_name=file_name,
        extension=extension)
    return file_path

def upload_path_self(instance, old_filename):
    extension = os.path.splitext(old_filename)[1].lower()
    file_name = os.path.splitext(old_filename)[0]
    today = datetime.datetime.today()
    # timestamp = int(time.time())
    # rand = random.randint(1,10000)

    file_path = 'self_upload/{user}/{date_time}/{file_name}{extension}'.format(
        user=instance.user,
        date_time=datetime.datetime.now().strftime('%Y-%m-%d'),
        file_name=file_name,
        extension=extension)
    return file_path

def upload_path_task(instance, old_filename):
    extension = os.path.splitext(old_filename)[1].lower()
    file_name = os.path.splitext(old_filename)[0]

    file_path = 'task_upload/{user}/{date_time}/{file_name}{extension}'.format(
        user=instance.user,
        date_time=datetime.datetime.now().strftime('%Y-%m-%d'),
        file_name=file_name,
        extension=extension)
    return file_path

# define Project Manager
class ProjectManager(models.Manager):
    def get_all_projects_by_page(self, user, num=10, current_page=1):
        count = self.get_queryset().count()
        page = Pages(count, current_page, num)
        query = self.get_queryset().filter(user=user).order_by('-created_time')[page.start:page.end]
        return query, page

    def get_all_projects(self):
        return self.get_queryset().all().order_by('-created_time')

    def get_recent_projects(self):
        return self.all().order_by('-created_time')[:50]


# 项目
class Project(models.Model):
    name = models.CharField(max_length=50,  default="项目名称", verbose_name="项目名称")
    type = models.CharField(max_length=50, default='10kmop', verbose_name="项目类型")
    state = models.CharField(max_length=50, default='分析中', verbose_name="项目状态")
    created_time = models.DateTimeField(default=timezone.now, verbose_name="项目创建时间")
    progress = models.CharField(max_length=50, default='20', verbose_name="项目进度")
    user = models.ManyToManyField(User, related_name="project_user", verbose_name="项目所有用户")
    white = models.IntegerField(default=0,verbose_name="已完成")
    black = models.IntegerField(default=0,verbose_name="未完成")
    white_file = models.FileField(upload_to=upload_path_txt,  verbose_name="白名单文件")
    black_file = models.FileField(upload_to=upload_path_txt,  verbose_name="黑名单文件")
    post_flag = models.BooleanField(default=False, verbose_name="是否通过apipost")
    samples = models.TextField(null=True, blank=True, verbose_name='所有samples')


    def save(self, *args, **kwargs):
        if Project.objects.filter(name=self.name):
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + '/media/project_txt/'
            if self.post_flag:
                base_path = base_dir + str(self.name)
                if not os.path.isdir(base_path):
                    os.makedirs(base_path)
                try:
                    os.remove(os.path.join(base_path, self.white_file.name))
                    os.remove(os.path.join(base_path, self.black_file.name))
                except:
                    pass
                with open(os.path.join(base_path, self.white_file.name), 'wb') as white_file:
                    white_file.write(self.white_file.read())
                with open(os.path.join(base_path, self.black_file.name), 'wb') as black_file:
                    black_file.write(self.black_file.read())
                Project.objects.filter(name=self.name).update(post_flag=False, progress=self.progress, white_file= 'project_txt/' + str(self.name) + '/' + self.white_file.name,
                                                              black_file= 'project_txt/' + str(self.name) + '/' + self.black_file.name,
                                                              white = self.white, black = self.black, samples=self.samples)


        else:
            self.post_flag = False
            super(Project, self).save(*args, **kwargs)


    def __str__(self):
        return self.name

    objects = ProjectManager()

class Task(models.Model):
    name = models.CharField(max_length=50, null=True, blank=True, verbose_name="任务名称")
    user = models.CharField(max_length=50, null=True, blank=True, verbose_name="用户")
    created_time = models.DateTimeField(default=timezone.now, verbose_name="创建时间")
    samples_1 = models.CharField(max_length=500, null=True, blank=True, verbose_name="比较组1")
    samples_2 = models.CharField(max_length=500, null=True, blank=True, verbose_name="比较组2")
    diff = models.CharField(max_length=50, null=True, blank=True, verbose_name="diff")
    p = models.CharField(max_length=50, null=True, blank=True, verbose_name="p")
    state = models.CharField(max_length=50, default='分析中', verbose_name="状态")
    img1 = models.ImageField(upload_to=upload_path_task, null=True,  verbose_name="img1")
    img2 = models.ImageField(upload_to=upload_path_task, null=True,  verbose_name="img1")
    file1 = models.FileField(upload_to=upload_path_task, null=True, verbose_name="file1")
    file2 = models.FileField(upload_to=upload_path_task, null=True, verbose_name="file2")


    def save(self, *args, **kwargs):
        task = Task.objects.filter(name=self.name)
        if task:
            if not self.state:
                base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + '/media/task_upload/'
                base_path = base_dir + str(task[0].user)
                if not os.path.isdir(base_path):
                    os.makedirs(base_path)

                filename1 = os.path.splitext(self.file1.name)[0][:]
                filename2 = os.path.splitext(self.file2.name)[0][:]
                with open(os.path.join(base_path, self.img1.name), 'wb') as img1:
                    img1.write(self.img1.read())
                with open(os.path.join(base_path, self.img2.name), 'wb') as img2:
                    img2.write(self.img2.read())
                with open(os.path.join(base_path, filename1 + '.csv'), 'wb') as file1:
                    file1.write(self.file1.read())
                with open(os.path.join(base_path, filename2 + '.csv'), 'wb') as file2:
                    file2.write(self.file2.read())

                Task.objects.filter(name=self.name).update(state='结束',
                                                           img1='task_upload/' + str(task[0].user) + '/' + self.img1.name,
                                                           img2='task_upload/' + str(task[0].user) + '/' + self.img2.name,
                                                           file1='task_upload/' + str(task[0].user) + '/' + filename1 + '.csv',
                                                           file2='task_upload/' + str(task[0].user) + '/' + filename2 + '.csv',
                                                           )
            else:
                Task.objects.filter(name=self.name).update(state='错误')

        else:
            super(Task, self).save(*args, **kwargs)

# 数据
class Data(models.Model):
    name = models.CharField(max_length=200, null=True, blank=True, verbose_name="文件名")
    created_time = models.DateTimeField(default=timezone.now, verbose_name="创建时间")
    size = models.CharField(max_length=50, null=True, blank=True, verbose_name="大小")
    file_type = models.CharField(max_length=50, null=True, blank=True, verbose_name="文件类型")
    file = models.FileField(upload_to=upload_path, blank=True, null=True, verbose_name="上传文件")
    # user = models.ForeignKey(User, related_name="data_user", verbose_name="用户")
    project = models.CharField(max_length=50, null=True, blank=True, verbose_name="项目")

    def save(self, *args, **kwargs):

        if self.project:
            project_obj = Project.objects.filter(name=self.project)
            if not project_obj:
                project_obj = Project(name=self.project)
                project_obj.save()


        if self.file:
            try:
                self.file.name = self.file.name.split('/')[-1]
            except:
                self.file.name =  self.file.name
            e = os.path.splitext(str(self.file))[1][1:]  # get .ext and remove dot
            self.file_type = e
            if not self.name:
                self.name = os.path.splitext(str(self.file))[0]
            if not self.size:
                self.size = str(round(self.file.size/1024/1024,3)) + 'M'
            print(self.file.path)

        super(Data, self).save()

class SelfData(models.Model):
    name = models.CharField(max_length=200, null=True, blank=True, verbose_name="文件名")
    created_time = models.DateTimeField(default=timezone.now, verbose_name="创建时间")
    size = models.CharField(max_length=50, null=True, blank=True, verbose_name="大小")
    file_type = models.CharField(max_length=50, null=True, blank=True, verbose_name="文件类型")
    file = models.CharField(max_length=200, null=True, blank=True, verbose_name="文件路径")
    user = models.ForeignKey(User, related_name="data_user", verbose_name="用户")
    project = models.CharField(max_length=50, default='无', null=True, blank=True, verbose_name="项目")



    def __str__(self):
        return self.name


class Profile(models.Model):
    GENDER_CHOICES = (
        (u'男', u'男'),
        (u'女', u'女'),
    )

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    sex = models.CharField(max_length=50,null=True, blank=True, choices=GENDER_CHOICES,verbose_name="性别")  # 性别
    img = models.ImageField(upload_to = 'pic_folder/', default='pic_folder/no-img.jpg',verbose_name="头像")
    intro = models.TextField(max_length=500,null=True, blank=True,verbose_name="简介")  # 简介
    address = models.CharField(max_length=50,null=True, blank=True,verbose_name="地址")  # 地址
    company = models.CharField(max_length=50,null=True, blank=True,verbose_name="公司")  # 工作单位
    phone = models.CharField(max_length=50,null=True, blank=True,verbose_name="电话")  # 电话
    mobile = models.CharField(max_length=50,null=True, blank=True,verbose_name="手机号码")  # 电话
    title = models.CharField(max_length=50,null=True, blank=True,verbose_name="职称")  # 职称

    def __unicode__(self):
        return self.user.username



@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)


@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    instance.profile.save()

# def my_handler(sender, instance, created, **kwargs):
#     notify.send(instance, verb='was saved')
#
# post_save.connect(my_handler, sender=User)
