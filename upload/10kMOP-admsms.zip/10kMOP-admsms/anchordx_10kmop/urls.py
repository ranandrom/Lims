"""anchordx_10kmop URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.10/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url, include
from django.contrib import admin
from tenkmop import views, chartView, dataView
from django.conf import settings
from django.conf.urls.static import static
import notifications.urls
from rest_framework.routers import DefaultRouter



router = DefaultRouter()
router.register(r'datas_api', dataView.DataViewSet)
router.register(r'projects_api', dataView.ProjectViewSet)
router.register(r'users_api', dataView.UserViewSet)
router.register(r'task_api', dataView.TaskViewSet)

urlpatterns = [
                  url(r'^admin/', admin.site.urls, name='admin'),
                  url(r'^$', views.index),
                  url(r'^index/$', views.index, name='index'),
                  url(r'^login/$', views.userlogin, name='login'),
                  url(r'^logout/$',views.userlogout, name='logout'),
                  url(r'^changepwd/$',views.changepwd, name='changepwd'),

                  url(r'^anchordxchart/$', views.anchordxChart, name='anchordxchart'),
                  url(r'^admsms/$', views.admsms, name='admsms'),

                  url(r'^methy_data/$', views.methylation_data,name='methy_data'),
                  url(r'^dss_analysis/(?P<project_id>[0-9]+)$', views.dss_analysis,name='dss_analysis'),
                  url(r'^dss_analysis_index/$', views.dss_analysis_index,name='dss_analysis_index'),
                  url(r'^post_dss_analysis/$', views.post_dss_analysis,name='post_dss_analysis'),
                  url(r'^dss_analysis_result/(?P<task_id>[0-9]+)$', views.dss_analysis_result,name='dss_analysis_result'),

                  url(r'^my_projects/$', views.my_projects, name='my_projects'),
                  url(r'^project_detail/(?P<project_id>[0-9]+)$', views.project_detail, name='project_detail'),
                  url(r'^my_datas/$', views.mydatas, name='my_datas'),
                  url(r'^my_projects_and_datas/$', views.myprojectsanddatas, name='my_projects_and_datas'),
                  url(r'^profile/$', views.profile, name='profile'),
                  url(r'^upload_tab/$', views.upload_tab, name='upload_tab'),
                  url(r'^upload_file/(?P<id>[\w-]+)/$', views.upload_file, name='upload_file'),

                  url(r'^analysis/$', views.analysis, name='analysis'),
                  url(r'^datas/$', views.datas, name='datas'),


                  url(r'^anchorchart/$', chartView.anchor_chart, name='anchorchart'),
                  url(r'^get_chart/(?P<id>[\w-]+)/$', views.get_chart, name='get_chart'),
                  url(r'^get_chart_self/(?P<id>[\w-]+)/$', views.get_chart_self, name='get_chart_self'),
                  url(r'^get_chart_task/(?P<path>(.*)+)/$', views.get_chart_task, name='get_chart_task'),
                  url(r'^anchorchartree/', chartView.chart_tree),
                  url(r'^dirlistforchart/', chartView.dir_list_for_chart),
                  url(r'^dirlistforchart_self/', chartView.dir_list_for_chart_self),
                  url(r'^getcolnames/', chartView.get_col_names),
                  url(r'^getchartdatas/', chartView.get_chart_datas),




                  url(r'^', include(router.urls)),
                  url(r'^api-auth/', include('rest_framework.urls', namespace='rest_framework'))


              ] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
